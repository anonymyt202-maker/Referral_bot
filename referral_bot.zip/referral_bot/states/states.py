from aiogram.fsm.state import StatesGroup
from aiogram.fsm.state import State


class SupportState(StatesGroup):
    waiting_message = State()
    waiting_reply = State()


class WithdrawState(StatesGroup):
    waiting_phone = State()
    waiting_card = State()
    waiting_amount = State()


class PromoState(StatesGroup):
    waiting_promocode = State()


class AdminState(StatesGroup):
    waiting_broadcast = State()
    waiting_channel = State()
    waiting_user = State()
    waiting_balance = State()

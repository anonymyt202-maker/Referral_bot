aiogram==3.4.1
sqlalchemy==2.0.29
asyncpg==0.29.0
python-dotenv==1.0.1
psycopg2-binary==2.9.9
redis==5.0.3
greenlet==3.0.3

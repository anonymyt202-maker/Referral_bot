from aiogram import Router
from aiogram.types import Message

from data.config import ADMIN_ID

router = Router()


@router.message(lambda message: message.from_user.id == ADMIN_ID)
async def admin_panel(message: Message):

    if message.text == "/admin":

        await message.answer(
            "Admin paneliga xush kelibsiz ✅"
        )

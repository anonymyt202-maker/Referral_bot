from aiogram import Router
from aiogram.types import Message

router = Router()


@router.message(lambda message: message.text == "👤 Hisobim")
async def profile_handler(message: Message):

    text = """
👤 Hisobingiz:

💰 Balans: 0 so'm
👥 Referallar: 0 ta
"""

    await message.answer(text)

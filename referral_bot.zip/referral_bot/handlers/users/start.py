from aiogram import Router
from aiogram.types import Message
from aiogram.filters import CommandStart

from keyboards.reply import main_menu

router = Router()


@router.message(CommandStart())
async def start_handler(message: Message):

    text = f"""
Assalomu alaykum {message.from_user.full_name}

Botga xush kelibsiz ✅
"""

    await message.answer(
        text=text,
        reply_markup=main_menu
    )

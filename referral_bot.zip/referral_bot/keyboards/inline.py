from aiogram.types import InlineKeyboardMarkup
from aiogram.types import InlineKeyboardButton


def admin_reply_button(user_id):

    keyboard = InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(
                    text="Javob qaytarish",
                    callback_data=f"reply_{user_id}"
                )
            ]
        ]
    )

    return keyboard

from aiogram.types import ReplyKeyboardMarkup
from aiogram.types import KeyboardButton


main_menu = ReplyKeyboardMarkup(
    keyboard=[
        [
            KeyboardButton(text="💰 Pul ishlash")
        ],
        [
            KeyboardButton(text="👤 Hisobim"),
            KeyboardButton(text="💸 Pul yechish")
        ],
        [
            KeyboardButton(text="🎁 Promocode"),
            KeyboardButton(text="📋 Vazifalar")
        ],
        [
            KeyboardButton(text="📢 Homiy bo'lish"),
            KeyboardButton(text="👨‍💻 Adminga murojat")
        ]
    ],
    resize_keyboard=True
)

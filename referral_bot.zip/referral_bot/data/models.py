from sqlalchemy.orm import DeclarativeBase
from sqlalchemy.orm import Mapped
from sqlalchemy.orm import mapped_column

from sqlalchemy import BigInteger
from sqlalchemy import String
from sqlalchemy import Boolean


class Base(DeclarativeBase):
    pass


class User(Base):
    __tablename__ = "users"

    id: Mapped[int] = mapped_column(primary_key=True)

    telegram_id: Mapped[int] = mapped_column(
        BigInteger,
        unique=True
    )

    username: Mapped[str] = mapped_column(
        String,
        nullable=True
    )

    full_name: Mapped[str] = mapped_column(
        String
    )

    balance: Mapped[int] = mapped_column(
        default=0
    )

    referrals: Mapped[int] = mapped_column(
        default=0
    )

    invited_by: Mapped[int] = mapped_column(
        BigInteger,
        nullable=True
    )

    task_count: Mapped[int] = mapped_column(
        default=0
    )

    banned: Mapped[bool] = mapped_column(
        Boolean,
        default=False
    )
